# Lab 5: Buy Grades For Money

In this exercises, you should make a form which takes payment information from suckers who want to buy a grade, and store it in a `suckers.txt` file.


### Student Details:

- **Student ID**: your student id
- **Student Name**: your name
- **Section Number**: your section number
